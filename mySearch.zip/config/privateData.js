/////////////////////////////////////////////////////////////
//////////AUTHORS :   chocof (https://github.com/chocof)/////
//////////File :   config/database.js               /////////
/////////////////////////////////////////////////////////////

//database url to read from
module.exports = {
	'url' 			: 'mongodb://chocof:choco@ds035583.mongolab.com:35583/mysearchdb',
	'googleApiKey'	: 'AIzaSyBhqX1qoqaMhOvYSny7SrUtqHMx-aLDrgU'
	
}
