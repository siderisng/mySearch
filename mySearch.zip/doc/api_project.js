define({
  "name": "mySearch-stack",
  "version": "0.0.0",
  "description": "Server to handle requests made from the android app as well as handle data and use them to display history in the website",
  "sampleUrl": false,
  "apidoc": "0.2.0",
  "generator": {
    "name": "apidoc",
    "time": "2015-09-25T14:55:44.559Z",
    "url": "http://apidocjs.com",
    "version": "0.13.1"
  }
});